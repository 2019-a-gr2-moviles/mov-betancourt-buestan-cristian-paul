package com.example.aplicacion2

class Persona(
    var nombre: String,
    var cedula: String
) {

}