package com.example.examen2b.valoresEstaticos

import com.example.examen2b.modelo.Medicamento

class Datos {

    companion object {
        var nombreUsuario: String = ""
        var listaMedicamento: ArrayList<Medicamento> = arrayListOf()
    }
}