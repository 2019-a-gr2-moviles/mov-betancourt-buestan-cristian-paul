package com.example.examen2b.modelo

class Paciente(
    var medicamentoDePaciente: ArrayList<Medicamento>?,
    var id: Int,
    var nombres: String,
    var apellidos: String,
    var fechaNacimiento: String,
    var hijos: Int,
    var tieneSeguro: Boolean

//
) {
}