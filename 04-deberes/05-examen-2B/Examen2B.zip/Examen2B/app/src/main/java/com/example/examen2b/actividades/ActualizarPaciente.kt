package com.example.examen2b.actividades

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.examen2b.R

class ActualizarPaciente : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actualizar_paciente)
    }
}
