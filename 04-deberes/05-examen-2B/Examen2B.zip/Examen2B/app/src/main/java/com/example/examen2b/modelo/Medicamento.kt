package com.example.examen2b.modelo

class Medicamento(
    var id: Int,
    var gramosAIngerir: Double,
    var nombre: String,
    var composicion: String,
    var usadoPara: String,
    var fechaCaducidad: String,
    var numeroPastillas: Int,
    var idPaciente: Int
){

}